# HMOD

## 1. preprocess data

python  preprocess_data.py

### 2. train

python train_processed_EAHM.py